#include <stdio.h> //including header file

int main()
         {
         printf("Name: Adya\n Roll No.: 2410110027\n Department: Computer Science and Engineering\n School: School of Engineering\n Address: SNIoE Delhi, NCR\n");
         }