#include<stdio.h>

int factfor(int n){
    int result=1;
    for(int i=1; i<=n; i++){
        result*=i;
    }
    return result;

}
int factrecur(int m){
    if (m==0 || m==1){
        return 1;
    }
    else{
        return (m*factrecur(m-1));
    }
}

int main(){
    int num;
    printf("Enter num: ");
    scanf("%d", &num);
    int res1= factfor(num);
    printf("Using for loop: %d\n", res1);
    int res2= factrecur(num);
    printf("Using recursion: %d\n", res2);

}